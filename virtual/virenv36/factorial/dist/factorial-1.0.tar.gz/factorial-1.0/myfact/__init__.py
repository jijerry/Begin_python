from fact import factor
__all__ = [factor,]
