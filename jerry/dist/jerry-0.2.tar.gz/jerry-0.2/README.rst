MANIFEST.in:文件作用在使用sdist命令时候找出将成为项目源代码压缩包的一部分所有文件，排除某些文件使用exclude语句
setup.py:创建压缩包或者安装软件
.pypirc:存放账号详细信息
